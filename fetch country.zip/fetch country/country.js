// var headers = new Headers();
// headers.append("X-CSCAPI-KEY", "API_KEY");

// var requestOptions = {
//   method: 'GET',
//   headers: headers,
//   redirect: 'follow'
// };

// fetch("https://raw.githubusercontent.com/sagarshirbhate/country-state-city-Database/master/Contries.json")
//   .then(response => response.json())
//   .then(result => 
//     console.log(result))

//   .catch(error => console.log('error', error));





// fetch("https://raw.githubusercontent.com/sagarshirbhate/country-state-city-Database/master/Contries.json")
// .then(response => response.json())
// .then(function (data) {
//     // let index =0;
//      let dataLength= data.Countries.length;
//      console.log(dataLength);
// });


// fetch("country.json")
//     .then(response => response.json())
//     .then(function (data) {
//         let index = 0;
//         let dataLength = data.Countries.length;
//         while (index < dataLength) {
//             document.getElementById("countries").innerHTML += "<option value=" + index + ">" + data.Countries[index].CountryName + "</option>";
//             ++index;
//         }
//         console.log(data);
//     });

// document.getElementById("countries").addEventListener("change",function () {
//     // document.getElementById("states").innerHTML ="";
//    let countryId=this.value;
    
// fetch("country.json")
// .then(response => response.json())
// .then(function (data) {
//     let index = 0;
//     let dataLength = data.Countries[countryId].States.length;
//     while (index < dataLength) {
//         document.getElementById("states").innerHTML += "<option value=" + index + ">" + data.Countries[countryId].States[index].StateName + "</option>";
//         ++index;
//     }
  
// });

// });

// document.getElementById("states").addEventListener("change",function () {
//     document.getElementById("cities").innerHTML ="";
//    let stateId=this.value;
    
// fetch("country.json")
// .then(response => response.json())
// .then(function (data) {
//     let countryId=document.getElementById("countries").value;
//     let index = 0;
//     let dataLength = data.Countries[countryId].States[stateId].Cities.length;
//     while (index < dataLength) {
//         document.getElementById("cities").innerHTML += "<option value=" + index + ">" + data.Countries[countryId].States[stateId].Cities[index] + "</option>";
//         ++index;
//     }
  
// });

// });


//  Create Mohammad mehedi hassan
fetch("country.json")
.then(response => response.json())
.then(function (data) {
    let index =0;
    let dataLength=data.Countries.length;
    while (index < dataLength) {
        document.getElementById("countries").innerHTML +=`<option value= ${index}>${data.Countries[index].CountryName}</option>`;
        ++index;
    }

});

document.getElementById("countries").addEventListener("change",function (){
     document.getElementById("states").innerHTML="";
   countryId =this.value;
    fetch("country.json")
    .then(response => response.json())
    .then(function (data) {
        let index =0;
        let dataLength=data.Countries[countryId].States.length;
        while (index < dataLength) {
            document.getElementById("states").innerHTML +=`<option value= ${index}>${data.Countries[countryId].States[index].StateName}</option>`;
            ++index;
        }


    });
    
});
document.getElementById("states").addEventListener("change",function (){
     document.getElementById("cities").innerHTML="";
stateId =this.value;
    fetch("country.json")
    .then(response => response.json())
    .then(function (data) {
        //  let countryId=document.getElementById("countries").value;
        let index =0;
        let dataLength=data.Countries[countryId].States[stateId].Cities.length;
        while (index < dataLength) {
            document.getElementById("cities").innerHTML +=`<option value= ${index}>${data.Countries[countryId].States[stateId].Cities[index]}</option>`;
            ++index;
        }

    });
    
});



















